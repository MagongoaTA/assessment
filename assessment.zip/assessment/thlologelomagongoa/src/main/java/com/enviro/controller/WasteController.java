

public package com.enviro.assessment.grad001.thlologelomagongoa.controller;

import com.enviro.assessment.grad001.thlologelomagongoa.dto.WasteCategoryDto;
import com.enviro.assessment.grad001.thlologelomagongoa.service.WasteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/waste")
public class WasteController {

    private final WasteService wasteService;

    public WasteController(WasteService wasteService) {
        this.wasteService = wasteService;
    }

    @GetMapping("/categories")
    public ResponseEntity<List<WasteCategoryDto>> getAllCategories() {
        return ResponseEntity.ok(wasteService.getAllCategories());
    }

    @GetMapping("/categories/{id}")
    public ResponseEntity<WasteCategoryDto> getCategoryById(@PathVariable Long id) {
        return ResponseEntity.ok(wasteService.getCategoryById(id));
    }

    @PostMapping("/categories")
    public ResponseEntity<WasteCategoryDto> createCategory(@Valid @RequestBody WasteCategoryDto categoryDto) {
        return ResponseEntity.ok(wasteService.createCategory(categoryDto));
    }

    @PutMapping("/categories/{id}")
    public ResponseEntity<WasteCategoryDto> updateCategory(@PathVariable Long id, @Valid @RequestBody WasteCategoryDto categoryDto) {
        return ResponseEntity.ok(wasteService.updateCategory(id, categoryDto));
    }

    @DeleteMapping("/categories/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Long id) {
        wasteService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }
}
 {
    
}
