package com.enviro.assessment.grad001.thlologelomagongoa.service;

import com.enviro.assessment.grad001.thlologelomagongoa.dto.WasteCategoryDto;
import com.enviro.assessment.grad001.thlologelomagongoa.entity.WasteCategory;
import com.enviro.assessment.grad001.thlologelomagongoa.repository.WasteRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WasteService {

    private final WasteRepository wasteRepository;

    public WasteService(WasteRepository wasteRepository) {
        this.wasteRepository = wasteRepository;
    }

    public List<WasteCategoryDto> getAllCategories() {
        return wasteRepository.findAll().stream()
                .map(WasteCategoryDto::fromEntity)
                .collect(Collectors.toList());
    }

    public WasteCategoryDto getCategoryById(Long id) {
        return WasteCategoryDto.fromEntity(wasteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found")));
    }

    public WasteCategoryDto createCategory(WasteCategoryDto categoryDto) {
        WasteCategory category = wasteRepository.save(categoryDto.toEntity());
        return WasteCategoryDto.fromEntity(category);
    }

    public WasteCategoryDto updateCategory(Long id, WasteCategoryDto categoryDto) {
        WasteCategory category = wasteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setName(categoryDto.getName());
        category.setDescription(categoryDto.getDescription());
        return WasteCategoryDto.fromEntity(wasteRepository.save(category));
    }

    public void deleteCategory(Long id) {
        if (!wasteRepository.existsById(id)) {
            throw new RuntimeException("Category not found");
        }
        wasteRepository.deleteById(id);
    }
}
