package com.enviro.assessment.grad001.thlologelomagongoa.repository;

import com.enviro.assessment.grad001.thlologelomagongoa.entity.WasteCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteRepository extends JpaRepository<WasteCategory, Long> {
}
  
}
